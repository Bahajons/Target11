const BaseApi = 'http://185.241.53.116/api/v1/';
export default BaseApi