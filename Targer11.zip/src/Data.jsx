export const about = [
    'Asoschisi Behzod Jalilov Muratovich',
    `O'z faoliyatini 2015-yil o'quv markaz sifatida boshlagan`,
    `Hozirgacha Toshkent shahri bo'ylab 10 dan ortiq filialga ega`,
    `Xalqaro unversitetlarga talabalarni yuborish va bu borada maslahatlar berish uchun 2018-yil "Target Consulting" bo'limi ham ochilgan`,
    `2021-yil Oktabr oyidan boshlab litsenziya asosida "Target" brendi ostida xususiy maktab faoliyati ham yo'lga qo'yilgan.`,
    `O'z o'quvchilarini xorijdagi eng yaxshi unversitetlarga tayyorlab kelmoqda...`
]
export const maqsad = [
    `Millat sha'ni va qadrini sifatli ta'lim-tarbiya orqali yuksaltirish.
    Yoshlarni kelajakda lider qilib tarbiyalash va hayotda maqsad qo‘yib yashashni o‘rgatish.`,
    `Abituriyentlarni xalqaro universitetlar yoki ularning Oʻzbekistondagi filiallariga tayyorlash orqali ularning sifatli bilim olishini taʼminlash.
    `,
    `TOP universitetlarda oʻqish niyatida boʻlgan yoshlarga universitetga hujjat topshirish va viza olish masalasida barcha maʼlumot hamda yordamlarni berish.`,
    `Yoshlarni abituriyentlik vaqtida studentdek, studentlik vaqtida esa biznes egasidek fikrlashi uchun zaruriy bilim va koʻnikmalar ulashish.`
]